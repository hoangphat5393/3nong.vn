@echo off
chcp 65001 > nul
echo Importing JSON collections into MongoDB database: 3nong
mongoimport --db 3nong --collection admin_menus --file collections\admin_menus.json --jsonArray --drop
mongoimport --db 3nong --collection album_items --file collections\album_items.json --jsonArray --drop
mongoimport --db 3nong --collection albums --file collections\albums.json --jsonArray --drop
mongoimport --db 3nong --collection cache --file collections\cache.json --jsonArray --drop
mongoimport --db 3nong --collection cache_locks --file collections\cache_locks.json --jsonArray --drop
mongoimport --db 3nong --collection categories --file collections\categories.json --jsonArray --drop
mongoimport --db 3nong --collection contacts --file collections\contacts.json --jsonArray --drop
mongoimport --db 3nong --collection countries --file collections\countries.json --jsonArray --drop
mongoimport --db 3nong --collection currencies --file collections\currencies.json --jsonArray --drop
mongoimport --db 3nong --collection customer_forget_pass_otp --file collections\customer_forget_pass_otp.json --jsonArray --drop
mongoimport --db 3nong --collection email_templates --file collections\email_templates.json --jsonArray --drop
mongoimport --db 3nong --collection failed_jobs --file collections\failed_jobs.json --jsonArray --drop
mongoimport --db 3nong --collection import_log --file collections\import_log.json --jsonArray --drop
mongoimport --db 3nong --collection jobs --file collections\jobs.json --jsonArray --drop
mongoimport --db 3nong --collection media_files --file collections\media_files.json --jsonArray --drop
mongoimport --db 3nong --collection menu_items --file collections\menu_items.json --jsonArray --drop
mongoimport --db 3nong --collection menus --file collections\menus.json --jsonArray --drop
mongoimport --db 3nong --collection order_items --file collections\order_items.json --jsonArray --drop
mongoimport --db 3nong --collection order_payments --file collections\order_payments.json --jsonArray --drop
mongoimport --db 3nong --collection orders --file collections\orders.json --jsonArray --drop
mongoimport --db 3nong --collection pages --file collections\pages.json --jsonArray --drop
mongoimport --db 3nong --collection password_reset_tokens --file collections\password_reset_tokens.json --jsonArray --drop
mongoimport --db 3nong --collection payment_methods --file collections\payment_methods.json --jsonArray --drop
mongoimport --db 3nong --collection permission_role --file collections\permission_role.json --jsonArray --drop
mongoimport --db 3nong --collection permissions --file collections\permissions.json --jsonArray --drop
mongoimport --db 3nong --collection product_categories --file collections\product_categories.json --jsonArray --drop
mongoimport --db 3nong --collection product_prices --file collections\product_prices.json --jsonArray --drop
mongoimport --db 3nong --collection products --file collections\products.json --jsonArray --drop
mongoimport --db 3nong --collection role_user --file collections\role_user.json --jsonArray --drop
mongoimport --db 3nong --collection roles --file collections\roles.json --jsonArray --drop
mongoimport --db 3nong --collection sessions --file collections\sessions.json --jsonArray --drop
mongoimport --db 3nong --collection settings --file collections\settings.json --jsonArray --drop
mongoimport --db 3nong --collection users --file collections\users.json --jsonArray --drop
echo Done!
pause
