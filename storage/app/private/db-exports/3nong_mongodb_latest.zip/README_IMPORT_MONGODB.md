# MongoDB JSON Export — 3nong

- Xuất lúc: 21/11/2026 03:00:42
- Tổng số collection: 33
- Định dạng: JSON Array chuẩn cho `mongoimport --jsonArray` & MongoDB Compass.

## Cách 1: Import bằng MongoDB Compass (Giao diện)
1. Giải nén file `.zip` này.
2. Mở MongoDB Compass -> chọn Database -> chọn Collection -> bấm **Add Data -> Import JSON** -> chọn file `collections/<ten_bang>.json`.

## Cách 2: Import hàng loạt 1 lệnh bằng CLI (`mongoimport`)
- **Windows:** Chạy file `import_mongodb.bat`
- **Linux / macOS:** Chạy `bash import_mongodb.sh`
